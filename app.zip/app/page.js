"use client";
import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import { useMediaQuery } from "@react-hook/media-query";
import Amihub from "./components/hero/Amihub";
// Import Swiper React components
import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";
import "./styles.css";
// import required modules
import { Autoplay, Pagination, Navigation } from "swiper";

import Airsyn from "./components/hero/Airsyn";
import Okupower from "./components/hero/Okupower";
import Proxie from "./components/hero/Proxie";
import WhatWeDo from "./components/hero/whatwedo/WhatWeDo";

export default function Home() {
  const [showSidebar, setShowSidebar] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  const progressCircle = useRef(null);
  const progressContent = useRef(null);
  const onAutoplayTimeLeft = (s, time, progress) => {
    progressCircle.current.style.setProperty("--progress", 1 - progress);
    progressContent.current.textContent = `${Math.ceil(time / 1000)}s`;
  };

  const isMobile = useMediaQuery("(max-width: 768px)");

  // toggle sidebar for mobile
  const toggleSideBar = () => {
    setShowSidebar(!showSidebar);
  };

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const handleClickOutside = (event) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setIsOpen(false);
    }
  };

  useEffect(() => {
    document.addEventListener("click", handleClickOutside, true);
    return () => {
      document.removeEventListener("click", handleClickOutside, true);
    };
  }, []);

  return (
    <main className="bg-[#F0EFEF]">
      {/* start nav */}
      <nav className="flex items-center justify-between w-full py-6 px-6 lg:px-[5rem] sticky top-0 z-[999] bg-[#F0EFEF]">
        {/* logo */}
        <h1 className="text-[#0A8C55] font-bold">
          <Image src="/logo.svg" alt="Logo" width={100} height={98} priority />
        </h1>

        {/* links */}
        <div className="flex justify-end w-[20rem] text-black">
          {/* <span>Home</span> */}
          <span class="relative inline-block" ref={dropdownRef}>
            <span
              onClick={toggleMenu}
              className="hover:text-[#377EAF]  focus:border focus:border-b-2 cursor-pointer active:text-[#377EAF]"
            >
              Product
            </span>
            {isOpen && (
              <ul className="absolute right-0 bg-white shadow-md rounded-md mt-2  py-2 w-[7rem]">
                <li>
                  <a
                    href="http://tronix.africa/AirSyn.html"
                    className="block px-4 py-2 text-gray-800 hover:bg-gray-200"
                  >
                    Airsyn
                  </a>
                </li>
                <li>
                  <a
                    href="http://okupower.amihub.africa"
                    className="block px-4 py-2 text-gray-800 hover:bg-gray-200"
                  >
                    Okupower
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="block px-4 py-2 text-gray-800 hover:bg-gray-200"
                  >
                    Proxie
                  </a>
                </li>
              </ul>
            )}
          </span>

          {/* <span>Contact</span> */}
        </div>

        {/* hamburger menu */}
        {/* <div className="flex sm:hidden" onClick={toggleSideBar}>
          <svg
            fill="none"
            stroke="currentColor"
            stroke-width="1.5"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true"
            className="text-black h-6 w-6"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"
            ></path>
          </svg>
        </div> */}
      </nav>
      {/* end nav */}

      {/* start hero section */}
      <Swiper
        spaceBetween={30}
        centeredSlides={true}
        autoplay={{
          delay: 5500,
          disableOnInteraction: false,
        }}
        pagination={{
          clickable: true,
        }}
        navigation={isMobile ? false : true}
        modules={[Autoplay, Pagination, Navigation]}
        onAutoplayTimeLeft={onAutoplayTimeLeft}
        className="mySwiper"
      >
        <SwiperSlide>
          <Amihub />
        </SwiperSlide>
        <SwiperSlide>
          <Airsyn />
        </SwiperSlide>
        <SwiperSlide>
          <Okupower />
        </SwiperSlide>
        <SwiperSlide>
          <Proxie />
        </SwiperSlide>
        <div className="autoplay-progress" slot="container-end">
          <svg viewBox="0 0 48 48" ref={progressCircle}>
            <circle cx="24" cy="24" r="20"></circle>
          </svg>
          <span ref={progressContent}></span>
        </div>
      </Swiper>
      {/* end hero section */}

      {/* start pattern one */}
      <section className="h-[186px] w-full ">
        <Image
          src="./pattern1.svg"
          alt="Girl"
          className="object-cover h-full w-full"
          width={1260}
          height={186}
          priority
        />
      </section>
      {/* end pattern one */}

      {/* start our mission */}
      <section className="flex items-center justify-between px-6 py-9 lg:px-[5rem] sm:space-x-9">
        {/* left section */}
        <section className="flex-1 h-[40rem] bg-red-500">
          <Image
            src="https://images.pexels.com/photos/3913025/pexels-photo-3913025.jpeg?auto=compress&cs=tinysrgb&w=600"
            alt="Girl"
            className="object-cover h-full w-full"
            width={1260}
            height={186}
            priority
          />
        </section>

        {/* right section */}
        <section className="w-full sm:w-[40rem]">
          {/* our mission first section */}
          <div className="flex items-center space-x-6 mb-10">
            <div className="w-[5rem] sm:w-[10rem] h-fit bg-green-300 flex">
              <Image
                src="./line1.svg"
                alt="Line"
                className="object-cover h-[3px] w-full "
                width={100}
                height={3}
                priority
              />
            </div>
            <h1 className="text-4xl text-[#0A8C55]">Our Mission</h1>
          </div>

          {/* our mission second section */}
          <p className="mb-5">
            Develop africas top products through robust incubation,
            acceleration, trade and investment oppurtunities to deliver global
            solutions
          </p>

          {/* our vision first section */}
          <div className="flex items-center space-x-6 mb-10 mt-10">
            <div className="w-[5rem] sm:w-[10rem] h-fit bg-green-300 flex">
              <Image
                src="./line1.svg"
                alt="Line"
                className="object-cover h-[3px] w-full "
                width={100}
                height={3}
                priority
              />
            </div>
            <h1 className="text-4xl text-[#0A8C55]">Our Vision</h1>
          </div>

          {/* our vision second section */}
          <div className="mb-5">
            <ul className="space-y-9 pl-5 mt-5 sm:mt-0 sm:pl-0">
              <li className="list-disc">
                Becoming the Leader in Africa Manufacturing Innovation that
                provides a range of top quality brands, products and services.
              </li>
              <li className="list-disc">
                impacting every aspect of the manufacturing business; from
                design, research and development, production, supply chain and
                logistics management through to sales, marketing and even end of
                life management.
              </li>
            </ul>
          </div>

          <section className="sm:hidden flex-1 h-[20rem] bg-red-500 mb-5">
            <Image
              src="https://images.pexels.com/photos/3913025/pexels-photo-3913025.jpeg?auto=compress&cs=tinysrgb&w=600"
              alt="Girl"
              className="object-cover h-full w-full "
              width={1260}
              height={186}
              priority
            />
          </section>
        </section>
      </section>
      {/* end our mission */}

      {/* start logo section */}
      <section className="px-6 lg:px-[5rem] h-[20rem] sm:h-[15rem] flex items-center">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-x-[1rem] gap-y-[1rem] sm:gap-y-0 w-[55rem]">
          <div className="h-[8rem] w-[10] sm:h-[10rem] sm:w-[13rem] border border-black flex justify-center items-center rounded-xl">
            <Image
              src="./okupowerlogo.svg"
              alt=""
              className="object-cover "
              width={200}
              height={200}
              priority
            />
          </div>
          <div className="h-[8rem] w-[10] sm:h-[10rem] sm:w-[13rem] border border-black flex justify-center items-center rounded-xl">
            <Image
              src="/proxielogo.png"
              alt=""
              className="object-cover "
              width={100}
              height={100}
              priority
            />
          </div>
          <div className="h-[8rem] w-[10] sm:h-[10rem] sm:w-[13rem] border border-black flex justify-center items-center rounded-xl">
            <Image
              src="/airsyn logo.png"
              alt=""
              className="object-cover "
              width={100}
              height={100}
              priority
            />
          </div>
          {/* <div className="h-[8rem] w-[10] sm:h-[10rem] sm:w-[13rem] border border-black flex justify-center items-center rounded-xl">
            <Image
              src="./companylogo1.svg"
              alt=""
              className="object-cover h-[100px] w-[100px]"
              width={100}
              height={100}
              priority
            />
          </div> */}
        </div>
      </section>
      {/* end logo section */}

      {/* start our core values */}
      <section className="flex flex-col sm:flex-row justify-between px-6 lg:px-[5rem] sm:space-x-9 items-center py-9 ">
        {/* left section */}
        <section className="hidden sm:flex space-y-[5rem] w-[80rem] h-[30rem]">
          <Image
            src="./pattern2.svg"
            alt=""
            className="object-cover h-[480px] w-[650px]"
            width={650}
            height={480}
            priority
          />
        </section>

        {/* right section */}
        <section className="w-full">
          {/* first section */}
          <div className="flex items-center sm:space-x-6 mb-10">
            <h1 className="text-4xl text-[#F2B123]">Our Core Values</h1>
          </div>

          {/* second section */}
          <div className="flex pl-5  space-x-12 sm:space-x-[13rem]">
            <ul className="space-y-9">
              <li className="list-disc">Creativity</li>
              <li className="list-disc">Efficiency</li>
            </ul>
            <ul className="space-y-9">
              <li className="list-disc">Simplicity</li>
              <li className="list-disc">Flexibility</li>
            </ul>
          </div>
        </section>
      </section>
      {/* end our core values */}

      {/* start airsyn */}
      <section className="flex items-center justify-between px-6 py-9 lg:px-[5rem] sm:space-x-9">
        {/* left section */}
        <section className="flex-1 h-[40rem] bg-red-500 px-6">
          <Image
            src="/airsyn-product-1.png"
            alt="Airsyn Product"
            className="object-contain h-full w-full"
            width={1260}
            height={186}
            priority
          />
        </section>

        {/* right section */}
        <section className="w-full sm:w-[40rem]">
          {/* first section */}
          <div className="flex items-center space-x-6 mb-10">
            <div className="w-[5rem] sm:w-[10rem] h-fit bg-green-300 flex">
              <Image
                src="./line1.svg"
                alt="Line"
                className="object-cover h-[3px] w-full "
                width={100}
                height={3}
                priority
              />
            </div>
            <h1 className="text-4xl text-[#D20202] font-bold">Airsyn</h1>
          </div>

          {/* second section */}
          <p className="mb-5">
            AirSyn is a personal and industrial air quality monitoring device.
            It monitors ambient air quality within an environment and can detect
            up to 16 pollutants simultaneously which makes it a perfect
            replacement for the traditional smoke detector and fire alarm
            installed in homes, offices, factories, public places etc, providing
            real-time monitoring for effective decision making.
          </p>

          {/* airsyn image */}
          <section className="sm:hidden flex-1 h-[20rem] bg-[#D20202] mb-5">
            <Image
              src="/airsyn-1.jpg"
              alt="Airsyn Logo"
              className="object-cover h-full w-full "
              width={1260}
              height={186}
              priority
            />
          </section>

          {/* why */}
          <h1 className="mt-10 pb-3 font-bold">Why Airsyn</h1>
          <div>
            <div>• Used as a wireless access point.</div>
            <div>
              • Used as a safety device in homes, offices, and other
              environments.
            </div>
            <div>
              • Used as an early warning system and HSE mitigation Instrument.
            </div>
            <div>
              • It can be locked to a specific network service provider,
              increase sales for telecoms operator through constant usage.
            </div>
          </div>

          {/* product features */}
          <h1 className="mt-10 pb-3 font-bold">Product Features</h1>
          <div className="sm:flex  sm:space-x-6 space-y-6 sm:space-y-0">
            <div>
              <div>• Simple installation</div>
              <div>• Up-To-The-Minute air quality update</div>
              <div>• Location-Based update</div>
              <div>• Air Quality Data Stored Securely on The Cloud</div>
              <div>• Ai-Enable Pattern Recognition</div>
            </div>
            <div>
              <div>• Mobile And App Enabled</div>
              <div>• Compatibility with wireless networks</div>
              <div>• Over 15m Wi-Fi range</div>
              <div>• Over 5 hours of battery life</div>
              <div>Remote monitoring and management</div>
              <div>• Rechargeable (solar, grid, and off-grid system)</div>
            </div>
          </div>
        </section>
      </section>
      {/* end airsyn */}

      {/* start proxie */}
      <section className="flex items-center justify-between px-6 py-9 lg:px-[5rem] sm:space-x-9">
        {/* left section */}
        <section className="w-full sm:w-[40rem]">
          {/* first section */}
          <div className="flex items-center space-x-6 mb-10">
            <div className="w-[5rem] sm:w-[10rem] h-fit bg-green-300 flex">
              <Image
                src="./line1.svg"
                alt="Line"
                className="object-cover h-[3px] w-full "
                width={100}
                height={3}
                priority
              />
            </div>
            <h1 className="text-4xl text-[#D20202] font-bold">Proxie</h1>
          </div>

          {/* second section */}
          <p className="mb-5">
            Proxie is an IoT-enabled smart socket that enables users to extend
            the coverage range of their WiFi network hotspot, as well as switch
            on and off appliances connected to it remotely. The device can be
            controlled both online as well as offline. It comes with a user
            interface for control. Proxie can be used in homes as well as
            industries due to it being built to handle up to 20amps of current
            at 110/250volts, and protects equipment with its surge protection
            capabilities.
          </p>
          {/* proxie image */}
          <section className="sm:hidden flex-1 h-[20rem] bg-[#D20202] mb-5">
            <Image
              src="/proxie-product.png"
              alt="Proxie Logo"
              className="object-contain h-full w-full "
              width={1260}
              height={186}
              priority
            />
          </section>
          {/* why */}
          <h1 className="mt-10 pb-3 font-bold">Why Proxie</h1>
          <div>
            <div>• Used as a wireless access point.</div>
            <div>
              • Used as a safety device in homes, offices, and other
              environments.
            </div>
            <div>
              • Used as an early warning system and HSE mitigation Instrument.
            </div>
            <div>
              • It can be locked to a specific network service provider,
              increase sales for telecoms operator through constant usage.
            </div>
          </div>
          {/* product features */}
          <h1 className="mt-10 pb-3 font-bold">Product Features</h1>
          <div className="sm:flex  sm:space-x-6 space-y-6 sm:space-y-0">
            <div>
              <div>
                • Used to deploy wireless network systems in offices, schools,
                hotels, homes, etc.
              </div>
              <div>• Used to extend the range of a Wi-Fi hotspot</div>
              <div>
                • Used to protect networking equipment and other appliances from
                power surges and static electricity
              </div>
            </div>
            <div>
              <div>• Used to optimize electricity management efficiency</div>
              <div>
                • Used to disable power remotely with its remote control feature
              </div>
            </div>
          </div>
        </section>

        {/* right section */}
        <section className="flex-1 h-[40rem] bg-[#D20202]">
          <Image
            src="/proxie-product.png"
            alt="Proxie Logo"
            className="object-contain h-full w-full"
            width={1260}
            height={186}
            priority
          />
        </section>
      </section>
      {/* end proxie */}

      {/* start okupower */}
      <section className="flex items-center justify-between px-6 py-9 lg:px-[5rem] sm:space-x-9">
        {/* left section */}
        <section className="flex-1 h-[40rem] bg-white">
          <Image
            src="/okupower_product-2.png"
            alt="Okupower Product"
            className="object-contain h-full w-full"
            width={1260}
            height={186}
            priority
          />
        </section>

        {/* right section */}
        <section className="w-full sm:w-[40rem]">
          {/* first section */}
          <div className="flex items-center space-x-6 mb-10">
            <div className="w-[5rem] sm:w-[10rem] h-fit bg-green-300 flex">
              <Image
                src="./line1.svg"
                alt="Line"
                className="object-cover h-[3px] w-full "
                width={100}
                height={3}
                priority
              />
            </div>
            <h1 className="text-4xl text-[#0A8C55] font-bold">Okupower</h1>
          </div>
          {/* second section */}
          <p className="mb-5">
            OkuPower is a digital prepaid electricity meter that measures the
            amount of electricity consumed by a facility. The product is
            designed to work in real-time showing the amount of power being
            consumed by the facility, showing the duration the current meter
            units carry, while making meter readings to be visible via a mobile
            device.
          </p>
          {/* okupower image */}
          <section className="sm:hidden flex-1 h-[20rem] bg-white mb-5">
            <Image
              src="/okupower_product-1.png"
              alt="Okupower Product"
              className="object-cover h-full w-full "
              width={1260}
              height={150}
              priority
            />
          </section>
          {/* why */}
          <h1 className="mt-10 pb-3 font-bold">Why Okupower</h1>
          <div>
            <div>
              • AC Power monitoring and management for any kind of environment
            </div>
            <div>
              • It can be used estate for sales of off-grid power to house or
              facility owners, hence it offers the enablement for monetization
              of off-grid power generating systems.
            </div>
            <div>• It offers first-level surge protection for facilities.</div>
            <div>
              • It can be locked to a specific network service provider,
              increase sales for telecoms operator through constant usage.
            </div>
          </div>
          {/* product features */}
          <h1 className="mt-10 pb-3 font-bold">Product Features</h1>
          <div className="sm:flex  sm:space-x-6 space-y-6 sm:space-y-0">
            <div className="sm:w-[50%]">
              <div>
                • It can be used to drive the sales of recharge cards, as it can
                interact with an API that enables airtime to be converted to
                legal tender (NGN) and use the money value to purchase power
                units automatically.
              </div>
            </div>
            <div className="sm:w-[50%]">
              <div>• Used to optimize electricity management efficiency</div>
              <div>
                • Used to disable power remotely with its remote control feature
              </div>
              <div>• The device can also be used as a network downlink.</div>
            </div>
          </div>
        </section>
      </section>
      {/* end okupower */}

      {/* start our accomplishment */}
      <section className="space-y-10 px-6 lg:px-[5rem] py-9">
        {/* first section */}
        <div className="flex items-center sm:justify-center sm:space-x-6 mb-10 w-full">
          <div className="w-[10rem] h-fit bg-green-300 flex">
            <Image
              src="./line1.svg"
              alt="Line"
              className="object-cover h-[3px] w-full "
              width={100}
              height={3}
              priority
            />
          </div>
          <h1 className="text-4xl">Our Accomplishments</h1>
        </div>

        {/* second section */}
        <p className="sm:text-center">
          AMIHUB a renowned organization dedicated to fostering technological
          innovation through their specialized technology incubators, showcased
          their unwavering commitment to promoting cutting-edge ideas and
          supporting emerging talents by sponsoring Tronix with their
          groundbreaking Proxie product as a formidable contender in the
          prestigious NCC annual innovation competition. As a testament to the
          exceptional capabilities and ingenuity of Tronix, their sponsored
          product, Proxie, outshined numerous competitors and emerged as a
          highly recognized runner-up, solidifying AMIHUB reputation as a
          catalyst for groundbreaking advancements in the industry. Furthermore,
          in their unwavering dedication to making a positive impact on the
          local community, AMIHUB extended their support by generously
          sponsoring a promising and passionate kids football club, nurturing
          the potential of young athletes and fostering a sense of discipline,
          and teamwork among the youth.
        </p>

        {/* third section */}
        <section className="flex justify-between">
          {/* left section */}
          <div className="w-full sm:w-[50rem] h-[40rem] bg-[#c7e8ff] p-6 space-y-6">
            {/* first row */}
            <div className="flex justify-between space-x-6 ">
              <div className="bg-red-500 h-[11.3rem] w-[20rem] sm:w-[30rem] ">
                <Image
                  src="/proxie-product2.jpg"
                  alt="Line"
                  className="object-cover h-[180.8px]"
                  width={480}
                  height={180.8}
                  priority
                />
              </div>
              <div className="bg-white flex items-center justify-center h-[11.3rem] w-[20rem] sm:w-[15rem]">
                <Image
                  src="/proxie-product.png"
                  alt="Line"
                  className="object-contain  "
                  width={480}
                  height={100}
                  priority
                />
              </div>
            </div>
            {/* second row */}
            <div className="flex justify-between space-x-6 ">
              <div className="bg-red-500 h-[11.3rem] w-[20rem] sm:w-[25rem]">
                <Image
                  src="/airsyn-1.jpg"
                  alt="Line"
                  className="object-cover h-[180.8px]"
                  width={480}
                  height={180.8}
                  priority
                />
              </div>
              <div className="bg-blue-500 h-[11.3rem] w-[20rem] sm:w-[15rem]">
                <Image
                  src="/airsyn-2.jpg"
                  alt="Line"
                  className="object-cover h-[180.8px]"
                  width={480}
                  height={180.8}
                  priority
                />
              </div>
              <div className="bg-blue-500 h-[11.3rem] w-[15rem] hidden sm:flex">
                <Image
                  src="/airsyn-3.jpg"
                  alt="Line"
                  className="object-cover h-[180.8px]"
                  width={480}
                  height={180.8}
                  priority
                />
              </div>
            </div>
            {/* third row */}
            <div className="flex justify-between space-x-6 ">
              <div className="bg-gray-400    flex items-center h-[11.3rem] w-[20rem] sm:w-[30rem]">
                <Image
                  src="/okupower_product-1.png"
                  alt="Line"
                  className="object-contain h-[140px]"
                  width={480}
                  height={180.8}
                  priority
                />
              </div>
              <div className="bg-white flex items-center h-[11.3rem] w-[20rem] sm:w-[15rem]">
                <Image
                  src="/okupower_product-2.png"
                  alt="Line"
                  className="object-contain h-[140.8px]"
                  width={480}
                  height={180.8}
                  priority
                />
              </div>
            </div>
          </div>

          {/* right section */}
          <div className="hidden sm:flex w-[20rem] h-[40rem]">
            <Image
              src="./pattern3.svg"
              alt=""
              className="object-cover h-[640px] w-[480px]"
              width={480}
              height={640}
              priority
            />
          </div>
        </section>
      </section>
      {/* end our accomplishment */}

      {/* start pattern two */}
      <section className="h-[186px] w-full ">
        <Image
          src="./pattern1.svg"
          alt="Girl"
          className="object-cover h-full w-full"
          width={1260}
          height={186}
          priority
        />
      </section>
      {/* end pattern two */}

      {/* start what we do */}
      <section className="px-6 lg:px-[5rem] py-[4rem] space-y-6">
        <h1 className="text-center text-4xl">What We Do</h1>
        <WhatWeDo isMobile={isMobile} />
      </section>
      {/* end what we do */}

      {/* start footer */}
      {/* NOTE: When ready reset the height back to h-[24rem] sm:h-[25rem] */}
      <footer className="bg-[#EBE9E9] px-6 lg:px-[5rem] h-[24rem] sm:h-[10rem] flex flex-col justify-between py-[4rem] ">
        {/* first section */}
        {/* NOTE: When ready remove hidden  */}
        <div className="sm:hidden flex flex-col sm:flex-row justify-between items-center sm:items-start">
          {/* first column */}
          <div className="sm:space-y-8 flex-1 items-center justify-between sm:block">
            {/* logo */}
            <div className="text-white">
              <Image
                src="/logo.svg"
                alt="Logo"
                width={100}
                height={98}
                priority
              />
            </div>
          </div>

          {/* second column */}
          <div className="flex-1 sm:flex-col sm:space-y-3 sm:space-x-0 space-x-4 mt-6 sm:mt-0">
            <h1 className="text-xl capitalize text-[#377EAF]">Airsyn</h1>
            {/* <div className="hidden sm:flex flex-col sm:flex-row sm:space-x-3">
              Lorem ipsum dolor sit amet consectetur. Sed mi ultrices ferment
            </div> */}
          </div>

          {/* third column */}
          <div className="flex-1 sm:flex-col sm:space-y-3 sm:space-x-0 space-x-4 mt-6 sm:mt-0">
            <h1 className="text-xl text-[#377EAF] capitalize">Okupower</h1>
            {/* <div className="hidden sm:flex flex-col sm:flex-row sm:space-x-3">
              Lorem ipsum dolor sit amet consectetur. Sed mi ultrices ferment
            </div> */}
          </div>

          {/* fourth column */}
          <div className="flex-1 sm:flex-col sm:space-y-3 sm:space-x-0 space-x-4 mt-6 sm:mt-0">
            <h1 className="text-xl text-[#377EAF] capitalize">Proxie</h1>
            {/* <div className="hidden sm:flex flex-col sm:flex-row sm:space-x-3">
              Lorem ipsum dolor sit amet consectetur. Sed mi ultrices ferment
            </div> */}
          </div>
        </div>

        {/* second section */}
        <div className="flex space-y-2 justify-center sm:justify-between sm:border-t border-[#515151] pt-6 pb-6">
          <div className="text-[#377EAF] hidden sm:flex items-center space-x-3">
            <div className="border border-[#377EAF] rounded-full w-5 h-5 flex items-center justify-center p-2">
              C
            </div>
            <div>all copy rights reserved</div>
          </div>
          <div className="flex justify-between items-center w-[10rem] ">
            <div>
              <a
                href="https://www.instagram.com/tronixafrica/"
                target="_blank"
                rel="noopener noreferrer"
              >
                {" "}
                <Image
                  src="/instagram.svg"
                  alt="instagram"
                  className=""
                  width={35}
                  height={35}
                  priority
                />
              </a>
            </div>
            <div>
              <a
                href="https://twitter.com/TronixAfrica"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Image
                  src="/twitter.svg"
                  alt="twitter"
                  className=""
                  width={35}
                  height={35}
                  priority
                />
              </a>
            </div>
            <div>
              <a
                href="https://web.facebook.com/TronixAfrica"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Image
                  src="/facebook.svg"
                  alt="facebook"
                  className=""
                  width={35}
                  height={35}
                  priority
                />
              </a>
            </div>
          </div>
          <div className="hidden sm:flex text-[#AF4FA2]">
            Check our more of our products
          </div>
        </div>
      </footer>
      {/* end footer */}
    </main>
  );
}
